function checkPassword() {
  const input = document.getElementById("password-input").value;
  const correct = "love"; // site password

  if (input.toLowerCase() === correct.toLowerCase()) {
    document.getElementById("password-screen").style.display = "none";
    document.getElementById("main-content").classList.remove("hidden");

    // fade out gold line then fade in background
    setTimeout(() => {
      document.getElementById("fade-line").classList.add("fade-out");
    }, 5000);

    setTimeout(() => {
      document.body.classList.add("active-bg");
    }, 8000);
  } else {
    alert("Incorrect password. Try again.");
  }
}
